#include "brainfuck.h"

Brainfuck::Brainfuck(std::string& str, std::istream* _in, std::ostream* _out): compiler(str), excecutor(str, _in, _out) {

}

bool Brainfuck::start(){
    bool is_all_ok = true;
    is_all_ok = compiler.start();
    if (! is_all_ok) return false;
    excecutor.start();
    return true;
}

Brainfuck::~Brainfuck() {
    
}
