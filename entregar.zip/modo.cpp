#include "modo.h"

Modo::Modo(std::istream* _in, std::ostream* _out) {
    this->in = _in;
    this->out = _out;
}
