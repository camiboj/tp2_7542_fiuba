#include <vector>
#include "bf_consumer.h"

BfConsumer::BfConsumer(bool& _result, std::mutex& _m, std::priority_queue \
            <BfPriority*, std::vector<BfPriority*>, CompareBf> \
            & _produced_bfs, \
            bool& _done, bool& _notified,  \
            std::condition_variable& _cond_var, int _i) : 
    result(_result), \
    m(_m), \
    produced_bfs(_produced_bfs), \
    done(_done), notified(_notified), \
    cond_var(_cond_var), i(_i) \
    {}
        
void BfConsumer::run() {
    std::unique_lock<std::mutex> lock(this->m);
    BfPriority* bf;
    //int j = 0;
    while (!this->done) {
        while (!this->notified) {  // loop to avoid spurious wakeups
            this->cond_var.wait(lock);
        }
        //j++;
        //std::cout << "ejecuto thread: " << i << '\n';
        //std::cout << "por vez: " << j << '\n';    
        notified = false;
        //std::cout << "consuming " << produced_nums.front() << '\n';
        bf = this->produced_bfs.top();
        this->produced_bfs.pop(); 
        
        //lock.unlock();  
        
        this->result = bf->start();
        delete bf;
    }       
}
