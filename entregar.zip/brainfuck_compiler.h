#ifndef BRAINFUCK_COMPILER_H_
#define BRAINFUCK_COMPILER_H_
#include <stack> 
#include <string>

class BrainfuckCompiler {
    private:
    std::string code;
    std::stack<char> my_stack;

    public:
    explicit BrainfuckCompiler(std::string& str);
    ~BrainfuckCompiler();
    bool start();
};

#endif
