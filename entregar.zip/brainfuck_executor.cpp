#include <iostream>
 #include <string>
#include "brainfuck_executor.h"
#define MAX_LEN_CODE_MEMORY 20000
#define MAX_LEN_DATA_MEMORY 200


BrainfuckExcecutor::BrainfuckExcecutor(std::string& str) {
    this->data_memory.resize(MAX_LEN_DATA_MEMORY);
    this->code_memory = str;
   
    std::fill(this->data_memory.begin(), this->data_memory.end(), 0);  
    this->data_pos = 0;

    this->code_pos = 0;
}

//<
void BrainfuckExcecutor::back() {
    this->data_pos--;
}

//>
void BrainfuckExcecutor::next() {
    this->data_pos++;
}

//+
void BrainfuckExcecutor::plus() {
    this->data_memory[this->data_pos]++;
}

//-
void BrainfuckExcecutor::less() {
    this->data_memory[this->data_pos]--;
}

//.
void BrainfuckExcecutor::out() {
    std::cout << this->data_memory[this->data_pos];
}

//,
void BrainfuckExcecutor::in() {
    this->data_memory[this->data_pos] = std::cin.get();
    if (this->data_memory[this->data_pos] == -1) {
        this->data_memory[this->data_pos] = 0;
    }
}

//[
void BrainfuckExcecutor::loopStart() {
    size_t count = 0;
    bool keep_looking = true;
    if ( this->data_memory[this->data_pos] ) return;
    while ( keep_looking ) {
        this->code_pos++;               
        if (this->code_memory.compare(this->code_pos, 1,"[") == 0) {
            count++;
        }
        if (this->code_memory.compare(this->code_pos, 1,"]") == 0) {
            if (count == 0) {
                keep_looking = false;
            } else {
                count--;
            }
        }
    }    
}     


//]
void BrainfuckExcecutor::loopEnd() {
    size_t count = 0;
    bool keep_looking = true;
    
    while (keep_looking) {
        this->code_pos--;
        if (this->code_memory.compare(this->code_pos, 1,"]") == 0) {
            count++;
        }
        if (this->code_memory.compare(this->code_pos, 1,"[") == 0) {
            if (count == 0) {
                keep_looking = false;
            } else {
                count--;
            }
        }
    }
    this->code_pos--;
}

void BrainfuckExcecutor::start() {
    while ( this->code_memory[this->code_pos] ) {
        switch ( this->code_memory[this->code_pos] ) {
            case '<':
                this->back();
                break;
            case '>':
                this->next();
                break;
            case '+':
                this->plus();
                break;
            case '-':
                this->less();
                break;
            case '.':
                this->out();
                break;
            case ',':
                this->in();
                break;
            case '[':
                this->loopStart();
                break;
            case ']':
                this-> loopEnd();
                break;
        }
        this->code_pos++;
    }
}

BrainfuckExcecutor::~BrainfuckExcecutor() {
    //do nothing
}

