#include <string>
#include <vector>
#include <cstring>
#include <sstream>
#include <queue> 
#include "interprete.h"

#define COMAND_ERROR 2



int main(int argc, char * const argv[]) {
    std::string modo1("interprete");


    if ( modo1.compare(0, strlen(argv[1]), argv[1]) == 0 ) {  
        //verifico la # de comandos
        if ( argc != 3 ) { 
            return COMAND_ERROR;
        }
        Interprete modo = Interprete(argv[2]);    
        return modo.execute();
           
    } else { return 1; }


    /*
    std::string modo1("thread-pool");
    if ( modo2.compare(0, strlen(argv[1]), argv[1]) == 0) {
        
        int thread = argv[2];
        ThreadPool modo = ThreadPool(thread);

    }
    */
    //return modo.execute();
}
