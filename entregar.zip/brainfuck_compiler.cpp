#include <iostream>
 #include <string>
#include "brainfuck_compiler.h"
#define ERROR_CODE 2
#define OK_CODE 0


BrainfuckCompiler::BrainfuckCompiler(std::string& str) {
    this->code = str;
}

BrainfuckCompiler::~BrainfuckCompiler() {
    //do nothing
}

bool BrainfuckCompiler::start() {
    char current = this->code[0]; 
    size_t pos = 0;
    
    while ( current ) {
        if ( current == '[' ) {
            this->my_stack.push(current);
        }
        if ( current == ']' ) {
            if (this->my_stack.empty()) {
                return false;
            }
            this->my_stack.pop();
        }
        pos ++;
        current = this->code[pos];
    }
    
    if ( !this->my_stack.empty() ) {
        return false;
    }
    return true;
}
