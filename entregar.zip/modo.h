#ifndef MODO_H_
#define MODO_H_
#include <iostream>
#define COMAND_ERROR 2
#define CODE_ERROR 1
#define OK 0

class Modo {
    protected:
    std::istream* in;
    std::ostream* out;

    public:
    Modo(std::istream* _in, std::ostream* _out);
    int excecute();
};



#endif