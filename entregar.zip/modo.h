#ifndef MODO_H_
#define MODO_H_
#include <iostream>
#define COMAND_ERROR 2
#define CODE_ERROR 1
#define OK 0

class Modo {
    public:
    //Modo();
    int excecute();
};

#endif
